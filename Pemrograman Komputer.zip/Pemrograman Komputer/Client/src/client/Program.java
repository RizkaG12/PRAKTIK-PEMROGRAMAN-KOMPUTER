
package client;


public class Program {

    public static void main(String[] args) {
        Application.setSystemLookAndFeel();
        Application.run();
    }
}
